#include "Liste.cpp"


int main(){

    //La partie en commentaire suivante est la série de commande
    //que j'ai rentré pour tester le fonctionnement des fonctions
    //au fur et à mesure
    
    /*ElementCh1 e1;
    e1.afficher();
    e1.setVal(12);
    e1.afficher();

    ElementCh1* e2 = new ElementCh1(14.48, nullptr);
    e2->afficher(); 
    e2->setVal(36);
    e2->afficher();

    double val = e2->getVal();
    cout << val << endl;

    ElementCh1* e3 = new ElementCh1(25, e2);
    e3->afficher();

    ElementCh1* e4 = new ElementCh1(756, &e1);
    e4->afficher();

    ElementCh1* e5 = new ElementCh1(6.6, e3);
    ElementCh1* e6 = new ElementCh1(2.04, e5);

    SuiteCh1 ch1;
    ch1.ajoutEnTete(12);
    ch1.ajoutEnTete(113);
    ch1.ajoutEnTete(1);
    ch1.effacerEnQueue();
    ch1.afficherComplet();

    Liste<int> L1;
    SuiteCh1<int> ch1;
    ch1.ajoutEnTete(12);
    ch1.ajoutEnTete(113);
    ch1.ajoutEnTete(0);
    SuiteCh1<int> ch2;
    ch1.ajoutEnTete(123);
    ch1.ajoutEnTete(-22);
    ch1.ajoutEnTete(98);
    ch1.ajoutEnTete(73.5);

    L1.afficherComplet();
    L1.ajoutListe(&ch1);
    L1.afficherComplet();
    L1.ajoutListe(&ch2);
    L1.afficherComplet();*/

    return 0;
}